TOOLS BY OUNCOPYBARA PRO v2.0.0
================================

តម្រូវការ៖ Windows 10/11 និង Python 3.10+ (ណែនាំ)។

របៀបដំណើរការ៖
1. ដំឡើង Python ពី python.org ហើយធីក Add Python to PATH។
2. ដាក់ឯកសារទាំងអស់ក្នុង Folder តែមួយ។
3. ចុចពីរដងលើ run_ouncopybara_pro.bat។
   ឬបើក CMD ហើយវាយ៖
   python -m pip install -r requirements_ouncopybara_pro.txt
   python tools_by_ouncopybara_pro.py

សាកល្បងជាមួយ Local Lab៖
1. ក្នុង Folder ដែលមាន index.html បើក CMD។
2. វាយ: py -m http.server 8000 --bind 127.0.0.1
3. ក្នុងកម្មវិធីបញ្ចូល http://127.0.0.1:8000 រួចចុច Analyze។

មុខងារ៖
- GUI Dark Mode សម្រាប់ Windows
- Passive HTTP response inspection (single URL)
- Security Headers និង Cookie attribute review
- Heuristic score (សម្រាប់ការរៀនប៉ុណ្ណោះ)
- Export JSON និង HTML reports

សុវត្ថិភាព និងដែនកំណត់៖
- ប្រើតែលើប្រព័ន្ធដែលអ្នកជាម្ចាស់ ឬមានការអនុញ្ញាត។
- មិនធ្វើ exploit, brute force, port scan ឬ follow redirects។
- មិនរក្សាទុក response body ឬតម្លៃ Cookie។
- ពិន្ទុមិនមែនជាការបញ្ជាក់ថាគេហទំព័រមានសុវត្ថិភាពទេ។
- ប្រើ HTTPS សម្រាប់ការតភ្ជាប់ដែលមានទិន្នន័យរសើប។
