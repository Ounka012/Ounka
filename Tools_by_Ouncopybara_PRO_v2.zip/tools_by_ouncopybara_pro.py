#!/usr/bin/env python3
# Tools by Ouncopybara PRO — Defensive Web Security Analyzer
# Passive HTTP inspection for systems you own or are authorized to test.
# Install: python -m pip install customtkinter aiohttp
# Run:     python tools_by_ouncopybara_pro.py

import asyncio
import json
import threading
import time
import html
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import tkinter as tk
from tkinter import filedialog, messagebox

try:
    import customtkinter as ctk
    import aiohttp
except ImportError as exc:
    raise SystemExit(
        "Missing packages. Run:\n"
        "python -m pip install customtkinter aiohttp"
    ) from exc


APP_NAME = "Tools by Ouncopybara PRO"
VERSION = "2.0.0"
BG = "#07111F"
PANEL = "#0B1B2E"
PANEL_ALT = "#102641"
BORDER = "#1B4266"
BLUE = "#168BFF"
CYAN = "#42D9F5"
GREEN = "#20D9A0"
ORANGE = "#FFB454"
RED = "#FF647C"
TEXT = "#EAF4FF"
MUTED = "#8FAAC7"

SECURITY_HEADERS = {
    "content-security-policy": "Helps restrict sources of scripts, styles, and other resources.",
    "strict-transport-security": "Tells browsers to prefer HTTPS for future requests.",
    "x-content-type-options": "Helps prevent MIME type sniffing.",
    "referrer-policy": "Controls how much referrer information is sent.",
    "permissions-policy": "Controls access to selected browser features.",
}

def validate_url(url):
    parsed = urlparse(url.strip())
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Enter a valid URL beginning with http:// or https://")
    if parsed.username or parsed.password:
        raise ValueError("Do not place usernames or passwords in the URL.")
    return parsed


async def inspect_url(url, max_body_kb=64):
    parsed = validate_url(url)
    started = time.perf_counter()
    timeout = aiohttp.ClientTimeout(total=15, connect=6)
    report = {
        "tool": APP_NAME,
        "version": VERSION,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "url": url,
        "scheme": parsed.scheme,
        "https": parsed.scheme == "https",
        "status_code": None,
        "reason": None,
        "final_url": None,
        "redirect_location": None,
        "content_type": None,
        "server_header": None,
        "response_time_ms": None,
        "body_sample_bytes_read": 0,
        "security_headers": [],
        "cookies": [],
        "findings": [],
        "scope": "Single-request passive HTTP inspection; redirects are not followed.",
    }

    # Default aiohttp TLS verification remains enabled.
    connector = aiohttp.TCPConnector()
    async with aiohttp.ClientSession(
        timeout=timeout,
        connector=connector,
        headers={"User-Agent": "Ouncopybara-Pro/2.0 (defensive security learning)"},
        trust_env=False,
    ) as session:
        async with session.get(url, allow_redirects=False) as response:
            report["status_code"] = response.status
            report["reason"] = response.reason
            report["final_url"] = str(response.url)
            report["redirect_location"] = response.headers.get("Location")
            report["content_type"] = response.headers.get("Content-Type", "Not specified")
            report["server_header"] = response.headers.get("Server", "Not disclosed")
            report["response_time_ms"] = round((time.perf_counter() - started) * 1000, 2)

            for name, purpose in SECURITY_HEADERS.items():
                value = response.headers.get(name)
                report["security_headers"].append({
                    "header": name,
                    "present": bool(value),
                    "value": value[:700] if value else "",
                    "purpose": purpose,
                })

            # Store cookie names and attributes only, never cookie values.
            for index, raw_cookie in enumerate(response.headers.getall("Set-Cookie", []), 1):
                parts = [part.strip() for part in raw_cookie.split(";")]
                first = parts[0] if parts else f"cookie-{index}"
                cookie_name = first.split("=", 1)[0][:120] if first else f"cookie-{index}"
                attrs = {part.split("=", 1)[0].strip().lower()
                         for part in parts[1:] if part}
                same_site = next(
                    (part.split("=", 1)[1].strip()
                     for part in parts[1:]
                     if part.lower().startswith("samesite=")),
                    "Not specified",
                )
                report["cookies"].append({
                    "name": cookie_name,
                    "secure": "secure" in attrs,
                    "httponly": "httponly" in attrs,
                    "samesite": same_site,
                    "path_present": any(a.startswith("path=") for a in attrs),
                    "domain_present": any(a.startswith("domain=") for a in attrs),
                })

            # Read a bounded sample only; do not save response body.
            sample = await response.content.read(max_body_kb * 1024)
            report["body_sample_bytes_read"] = len(sample)

    if not report["https"]:
        report["findings"].append({
            "severity": "High",
            "title": "HTTPS is not in use",
            "detail": "The URL uses HTTP. Sensitive data should be sent over HTTPS.",
            "recommendation": "Configure HTTPS and redirect HTTP to HTTPS where appropriate.",
        })

    missing = [item["header"] for item in report["security_headers"] if not item["present"]]
    if missing:
        report["findings"].append({
            "severity": "Info",
            "title": "Some security headers were not observed",
            "detail": ", ".join(missing),
            "recommendation": "Review which headers are suitable for this application. Absence alone does not prove a vulnerability.",
        })

    for cookie in report["cookies"]:
        absent = []
        if not cookie["secure"] and parsed.scheme == "https":
            absent.append("Secure")
        if not cookie["httponly"]:
            absent.append("HttpOnly")
        if cookie["samesite"] == "Not specified":
            absent.append("SameSite")
        if absent:
            report["findings"].append({
                "severity": "Medium",
                "title": f"Review cookie attributes: {cookie['name']}",
                "detail": "Attributes not observed: " + ", ".join(absent),
                "recommendation": "Set cookie attributes according to the cookie's purpose and application requirements.",
            })

    if 300 <= report["status_code"] < 400:
        report["findings"].append({
            "severity": "Info",
            "title": "Redirect response",
            "detail": f"HTTP {report['status_code']} with Location header: {report['redirect_location'] or 'not provided'}",
            "recommendation": "Review the redirect destination manually. Redirects are not followed by this tool.",
        })
    if report["status_code"] >= 500:
        report["findings"].append({
            "severity": "Medium",
            "title": "Server error response",
            "detail": f"Server returned HTTP {report['status_code']}.",
            "recommendation": "Review server logs and application health.",
        })

    # Transparent heuristic score for presentation, not a security certification.
    score = 100
    if not report["https"]:
        score -= 25
    score -= 7 * sum(1 for h in report["security_headers"] if not h["present"])
    score -= 5 * sum(1 for c in report["cookies"] if not c["secure"] and parsed.scheme == "https")
    score -= 5 * sum(1 for c in report["cookies"] if not c["httponly"])
    report["score"] = max(0, min(100, score))
    report["score_note"] = (
        "Heuristic educational score only. It is not a certification, penetration test, "
        "or proof that the application is secure."
    )
    return report


class OuncopybaraPro(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("1360x900")
        self.minsize(1050, 720)
        self.configure(fg_color=BG)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.last_report = None
        self.history = []
        self.busy = False
        self._build()

    def label(self, parent, text, size=12, color=TEXT, weight="normal"):
        return ctk.CTkLabel(parent, text=text,
            font=ctk.CTkFont(size=size, weight=weight),
            text_color=color, anchor="w", justify="left")

    def card(self, parent, **kwargs):
        return ctk.CTkFrame(parent, fg_color=PANEL, border_color=BORDER,
            border_width=1, corner_radius=13, **kwargs)

    def textbox(self, parent, font=("Consolas", 12)):
        box = ctk.CTkTextbox(parent, fg_color="#061321", text_color="#D7E9FC",
            border_color=BORDER, border_width=1, corner_radius=9,
            font=ctk.CTkFont(family=font[0], size=font[1]), wrap="word")
        return box

    def put_text(self, widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _build(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(self, fg_color="#06101D", corner_radius=0, height=82)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.grid_columnconfigure(1, weight=1)
        header.grid_propagate(False)
        mark = ctk.CTkFrame(header, fg_color="#10345A", corner_radius=14, width=52, height=52)
        mark.grid(row=0, column=0, padx=(20, 12), pady=14)
        mark.grid_propagate(False)
        self.label(mark, "◈", 30, CYAN, "bold").place(relx=.5, rely=.48, anchor="center")
        brand = ctk.CTkFrame(header, fg_color="transparent")
        brand.grid(row=0, column=1, sticky="w")
        self.label(brand, "Tools by Ouncopybara", 23, TEXT, "bold").pack(anchor="w")
        self.label(brand, "PRO  •  BETTER TOOLS  •  SAFER WEB  •  ETHICAL HACKING", 10, CYAN).pack(anchor="w")
        self.label(header, "● READY", 12, GREEN, "bold").grid(row=0, column=2, padx=24)

        side = ctk.CTkFrame(self, fg_color="#081626", corner_radius=0, width=222)
        side.grid(row=1, column=0, sticky="nsw")
        side.grid_propagate(False)
        self.label(side, "WORKSPACE", 10, MUTED, "bold").pack(anchor="w", padx=17, pady=(22, 9))
        for text, active in [
            ("▦   Dashboard", False),
            ("◎   Web Analyzer", True),
            ("◇   Security Headers", False),
            ("◉   Cookies & Sessions", False),
            ("▤   Report History", False),
        ]:
            ctk.CTkButton(side, text=text, anchor="w", height=37, corner_radius=8,
                fg_color="#10345B" if active else "transparent",
                hover_color="#153B5E", text_color=TEXT if active else MUTED,
                command=lambda: None).pack(fill="x", padx=10, pady=3)
        self.label(side, "LEARNING LAB", 10, MUTED, "bold").pack(anchor="w", padx=17, pady=(24, 9))
        self.label(side, "• HTTP Request / Response\n• Security Headers\n• Cookie Attributes\n• Defensive Recommendations", 11, MUTED).pack(anchor="w", padx=18)
        safety = self.card(side)
        safety.pack(side="bottom", fill="x", padx=11, pady=14)
        self.label(safety, "DEFENSIVE SECURITY", 10, GREEN, "bold").pack(anchor="w", padx=11, pady=(12, 5))
        self.label(safety, "ប្រើតែលើប្រព័ន្ធដែលអ្នក\nមានសិទ្ធិធ្វើតេស្ត។", 11, MUTED).pack(anchor="w", padx=11, pady=(0, 12))

        main = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        main.grid(row=1, column=1, sticky="nsew", padx=18, pady=16)
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(4, weight=1)

        self.label(main, "Web Security Analyzer", 23, TEXT, "bold").grid(row=0, column=0, sticky="w")
        self.label(main, "Passive HTTP inspection • Headers • Cookies • JSON / HTML reports", 12, MUTED).grid(row=0, column=0, sticky="w", pady=(33, 13))

        scan = self.card(main)
        scan.grid(row=1, column=0, sticky="ew", pady=(0, 13))
        scan.grid_columnconfigure(0, weight=1)
        self.label(scan, "TARGET URL", 10, CYAN, "bold").grid(row=0, column=0, sticky="w", padx=14, pady=(13, 5))
        row = ctk.CTkFrame(scan, fg_color="transparent")
        row.grid(row=1, column=0, sticky="ew", padx=13)
        row.grid_columnconfigure(0, weight=1)
        self.url_entry = ctk.CTkEntry(row, height=40, placeholder_text="http://127.0.0.1:8000",
            fg_color="#061222", border_color=BORDER, text_color=TEXT)
        self.url_entry.grid(row=0, column=0, sticky="ew", padx=(0, 9))
        self.url_entry.insert(0, "http://127.0.0.1:8000")
        self.scan_btn = ctk.CTkButton(row, text="▶  Analyze", width=140, height=40,
            fg_color=BLUE, hover_color="#0870D7", command=self.start_scan)
        self.scan_btn.grid(row=0, column=1)
        presets = ctk.CTkFrame(scan, fg_color="transparent")
        presets.grid(row=2, column=0, sticky="ew", padx=13, pady=(9, 2))
        self.label(presets, "Authorized Lab:", 10, MUTED).pack(side="left", padx=(0, 8))
        ctk.CTkButton(presets, text="localhost:8000", width=120, height=26,
            fg_color=PANEL_ALT, hover_color="#1A3B5B",
            command=lambda: self.set_url("http://127.0.0.1:8000")).pack(side="left", padx=3)
        ctk.CTkButton(presets, text="localhost:8080", width=120, height=26,
            fg_color=PANEL_ALT, hover_color="#1A3B5B",
            command=lambda: self.set_url("http://127.0.0.1:8080")).pack(side="left", padx=3)
        self.progress = ctk.CTkProgressBar(scan, height=4, progress_color=CYAN, fg_color=PANEL_ALT)
        self.progress.grid(row=3, column=0, sticky="ew", padx=14, pady=(10, 3))
        self.progress.set(0)
        self.status = self.label(scan, "Ready — បញ្ចូល URL របស់ Lab រួចចុច Analyze", 10, MUTED)
        self.status.grid(row=4, column=0, sticky="w", padx=14, pady=(4, 12))

        stats = ctk.CTkFrame(main, fg_color="transparent")
        stats.grid(row=2, column=0, sticky="ew", pady=(0, 13))
        for i in range(4):
            stats.grid_columnconfigure(i, weight=1)
        self.stat_values = []
        for i, (title, value, color) in enumerate([
            ("HEURISTIC SCORE", "—", CYAN), ("HTTP STATUS", "—", GREEN),
            ("RESPONSE TIME", "—", ORANGE), ("HEADERS FOUND", "—", GREEN)
        ]):
            card = self.card(stats)
            card.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 5, 5 if i < 3 else 0))
            self.label(card, title, 9, MUTED, "bold").pack(anchor="w", padx=12, pady=(10, 3))
            val = self.label(card, value, 22, color, "bold")
            val.pack(anchor="w", padx=12, pady=(0, 10))
            self.stat_values.append(val)

        results = self.card(main)
        results.grid(row=4, column=0, sticky="nsew")
        results.grid_columnconfigure(0, weight=1)
        results.grid_rowconfigure(1, weight=1)
        bar = ctk.CTkFrame(results, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", padx=13, pady=(11, 5))
        self.label(bar, "Analysis Results", 15, TEXT, "bold").pack(side="left")
        ctk.CTkButton(bar, text="Export JSON", width=105, height=29,
            fg_color="#123D45", hover_color="#175963", command=self.export_json).pack(side="right", padx=(7, 0))
        ctk.CTkButton(bar, text="Export HTML", width=105, height=29,
            fg_color="#12345A", hover_color="#174A77", command=self.export_html).pack(side="right")

        self.tabs = ctk.CTkTabview(results, fg_color=PANEL,
            segmented_button_fg_color="#10243A",
            segmented_button_selected_color=BLUE,
            segmented_button_selected_hover_color="#0870D7",
            segmented_button_unselected_color="#10243A")
        self.tabs.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        for tab in ("Summary", "Headers", "Cookies", "Raw JSON"):
            self.tabs.add(tab)
            self.tabs.tab(tab).grid_columnconfigure(0, weight=1)
            self.tabs.tab(tab).grid_rowconfigure(0, weight=1)
        self.summary_box = self.textbox(self.tabs.tab("Summary"), ("Segoe UI", 12))
        self.headers_box = self.textbox(self.tabs.tab("Headers"))
        self.cookies_box = self.textbox(self.tabs.tab("Cookies"))
        self.json_box = self.textbox(self.tabs.tab("Raw JSON"))
        for widget in (self.summary_box, self.headers_box, self.cookies_box, self.json_box):
            widget.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
            widget.configure(state="disabled")
        self.put_text(self.summary_box,
            "សូមចាប់ផ្ដើមដោយ Local Lab របស់អ្នក។\n\n"
            "1. បើក CMD នៅក្នុង Folder ដែលមាន index.html\n"
            "2. វាយ: py -m http.server 8000 --bind 127.0.0.1\n"
            "3. ចុច Analyze ជាមួយ http://127.0.0.1:8000\n\n"
            "ពិន្ទុគឺ heuristic សម្រាប់ការរៀន មិនមែនជាការបញ្ជាក់សុវត្ថិភាពទេ។")

        footer = ctk.CTkFrame(main, fg_color="transparent")
        footer.grid(row=5, column=0, sticky="ew", pady=(9, 0))
        self.label(footer, "● READY", 10, GREEN, "bold").pack(side="left")
        self.label(footer, "  Tools by Ouncopybara PRO  •  v2.0.0  •  Defensive use only", 10, MUTED).pack(side="left")

    def set_url(self, url):
        self.url_entry.delete(0, "end")
        self.url_entry.insert(0, url)

    def start_scan(self):
        if self.busy:
            return
        url = self.url_entry.get().strip()
        try:
            validate_url(url)
        except ValueError as exc:
            messagebox.showerror("Invalid URL", str(exc))
            return
        self.busy = True
        self.scan_btn.configure(state="disabled", text="Analyzing…")
        self.status.configure(text="Inspecting a single HTTP response…", text_color=CYAN)
        self.progress.configure(mode="indeterminate")
        self.progress.start()
        def worker():
            try:
                report = asyncio.run(inspect_url(url))
                self.after(0, lambda r=report: self.display_report(r))
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                self.after(0, lambda m=msg: self.scan_failed(m))
        threading.Thread(target=worker, daemon=True).start()

    def scan_failed(self, message):
        self.progress.stop()
        self.progress.configure(mode="determinate")
        self.progress.set(0)
        self.busy = False
        self.scan_btn.configure(state="normal", text="▶  Analyze")
        self.status.configure(text="Inspection failed — check URL / server / network", text_color=RED)
        messagebox.showerror("Inspection Error", message)

    def display_report(self, report):
        self.last_report = report
        self.history.append(report)
        self.progress.stop()
        self.progress.configure(mode="determinate")
        self.progress.set(1)
        self.busy = False
        self.scan_btn.configure(state="normal", text="▶  Analyze")
        self.status.configure(text=f"Completed • {report['url']}", text_color=GREEN)
        found = sum(1 for h in report["security_headers"] if h["present"])
        self.stat_values[0].configure(text=f"{report['score']}/100")
        self.stat_values[1].configure(text=str(report["status_code"] or "ERR"))
        self.stat_values[2].configure(text=f"{report.get('response_time_ms', '—')} ms")
        self.stat_values[3].configure(text=f"{found}/5")

        lines = [
            "TOOLS BY OUNCOPYBARA PRO — WEB ANALYZER",
            "=" * 56,
            f"URL: {report['url']}",
            f"HTTPS: {'Yes' if report['https'] else 'No'}",
            f"HTTP Status: {report['status_code']} {report.get('reason') or ''}",
            f"Content-Type: {report['content_type']}",
            f"Server Header: {report['server_header']}",
            f"Response Time: {report.get('response_time_ms')} ms",
            f"Heuristic Score: {report['score']}/100",
            "", "FINDINGS"
        ]
        if report["findings"]:
            for item in report["findings"]:
                lines += [f"[{item['severity']}] {item['title']}",
                          f"  Detail: {item['detail']}",
                          f"  Recommendation: {item['recommendation']}", ""]
        else:
            lines.append("No findings from this limited passive check.")
        lines += ["", report["score_note"], "", "Scope: " + report["scope"]]
        self.put_text(self.summary_box, "\n".join(lines))

        hlines = ["SECURITY HEADERS", "=" * 55, ""]
        for h in report["security_headers"]:
            hlines += [f"[{'FOUND' if h['present'] else 'NOT FOUND'}] {h['header']}",
                       f"Purpose: {h['purpose']}",
                       f"Value: {h['value'] or '(not observed)'}", ""]
        self.put_text(self.headers_box, "\n".join(hlines))

        clines = ["COOKIE ATTRIBUTES — Cookie values are never displayed or stored", "=" * 60, ""]
        if not report["cookies"]:
            clines.append("No Set-Cookie headers in this response.")
        for c in report["cookies"]:
            clines += [
                f"Cookie: {c['name']}",
                f"Secure: {'Yes' if c['secure'] else 'No'}",
                f"HttpOnly: {'Yes' if c['httponly'] else 'No'}",
                f"SameSite: {c['samesite']}",
                f"Path attribute: {'Yes' if c['path_present'] else 'No'}",
                ""
            ]
        self.put_text(self.cookies_box, "\n".join(clines))
        self.put_text(self.json_box, json.dumps(report, ensure_ascii=False, indent=2))

    def export_json(self):
        if not self.last_report:
            messagebox.showinfo("No report", "Run an analysis first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json", initialfile="ouncopybara_report.json",
            filetypes=[("JSON report", "*.json")])
        if path:
            try:
                Path(path).write_text(json.dumps(self.last_report, ensure_ascii=False, indent=2), encoding="utf-8")
                messagebox.showinfo("Exported", f"Saved report to:\n{path}")
            except OSError as exc:
                messagebox.showerror("Export error", str(exc))

    def export_html(self):
        if not self.last_report:
            messagebox.showinfo("No report", "Run an analysis first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".html", initialfile="ouncopybara_report.html",
            filetypes=[("HTML report", "*.html")])
        if not path:
            return
        r = self.last_report
        header_rows = "".join(
            "<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                html.escape(h["header"]), "Found" if h["present"] else "Not found",
                html.escape(h["value"] or "—"))
            for h in r["security_headers"])
        finding_rows = "".join(
            "<li><b>[{}] {}</b><br>{}<br><i>Recommendation: {}</i></li>".format(
                html.escape(f["severity"]), html.escape(f["title"]),
                html.escape(f["detail"]), html.escape(f["recommendation"]))
            for f in r["findings"]) or "<li>No findings from this limited passive check.</li>"
        doc = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tools by Ouncopybara PRO Report</title>
<style>
body{{font:16px Segoe UI,Arial;background:#07111f;color:#eaf4ff;margin:0;padding:32px}}
main{{max-width:1050px;margin:auto}}h1{{color:#42d9f5}}.card{{background:#0b1b2e;border:1px solid #1b4266;border-radius:14px;padding:20px;margin:16px 0}}
.score{{font-size:34px;color:#20d9a0}}table{{width:100%;border-collapse:collapse}}td,th{{padding:10px;border-bottom:1px solid #1b4266;text-align:left;overflow-wrap:anywhere}}
small{{color:#8faac7}}a{{color:#42d9f5}}
</style></head><body><main>
<h1>Tools by Ouncopybara PRO</h1><p>Defensive Web Security Report · {html.escape(r['checked_at'])}</p>
<div class="card"><div class="score">{r['score']}/100</div><p>Heuristic score only; not a certification.</p>
<p><b>URL:</b> {html.escape(r['url'])}<br><b>HTTPS:</b> {r['https']}<br>
<b>Status:</b> {r['status_code']} {html.escape(r.get('reason') or '')}<br>
<b>Content-Type:</b> {html.escape(str(r['content_type']))}<br><b>Response time:</b> {r.get('response_time_ms')} ms</p></div>
<div class="card"><h2>Security Headers</h2><table><tr><th>Header</th><th>Status</th><th>Value</th></tr>{header_rows}</table></div>
<div class="card"><h2>Findings & Recommendations</h2><ul>{finding_rows}</ul></div>
<div class="card"><small>Scope: {html.escape(r['scope'])}<br>{html.escape(r['score_note'])}</small></div>
</main></body></html>"""
        try:
            Path(path).write_text(doc, encoding="utf-8")
            messagebox.showinfo("Exported", f"Saved HTML report to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export error", str(exc))


if __name__ == "__main__":
    app = OuncopybaraPro()
    app.mainloop()
