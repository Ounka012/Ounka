@echo off
cd /d "%~dp0"
python -m pip install -r requirements_ouncopybara_pro.txt
if errorlevel 1 pause & exit /b 1
python tools_by_ouncopybara_pro.py
pause
